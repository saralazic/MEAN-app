import { Component, OnInit } from '@angular/core';
import { User } from '../../models/user';
import { Store } from '../../models/store'
import { Router } from '@angular/router';
import { ProductClass, Order, StoresService, ORDER_DELIVERING, ORDER_WAITING } from '../../services/stores.service';
import { UserService } from '../../services/user.service';
import * as d3 from 'd3';

@Component({
  selector: 'app-company',
  templateUrl: './company.component.html',
  styleUrls: ['./company.component.css']
})
export class CompanyComponent implements OnInit {
  user: User;
  store: Store;
  fetched: boolean;
  sh: boolean;

  shtrn: boolean;

  all_products: { pc: ProductClass, prodName: String }[];

  all_orders: { order: Order, i: number, j: number }[];

  constructor(private userserv: UserService, private storeserv: StoresService, private router: Router) { }

  displayedColumns: string[] = ['name', 'onstock', 'orders', 'grade'];

  ngOnInit(): void {
    this.shtrn = false;
    this.sh = false;
    this.fetched = false;
    this.all_orders = [];
    //Fetch company date and store data 
    //if company does not have store in database, create new store
    if (localStorage.getItem('userToken')) {
      this.user = this.userserv.getUserDetails();
      this.getStoreInfo();
    }
  }

  shturnover(){
    this.shtrn = !this.shtrn;
  }

  getStoreInfo() {
    this.storeserv.getStore(this.user._id).subscribe(
      (data) => {
        //  console.log(data);
        if (data == null) {
          this.storeserv.newStore(this.user._id).subscribe(() =>
            this.storeserv.getStore(this.user._id).subscribe(
              s => this.store = s
            )
          );
        }
        else this.store = data;
        if (this.store.turnover.length < 30) {
          while (this.store.turnover.length < 30) {
            this.store.turnover.push(0);
          }
          this.storeserv.updateStore(this.store).subscribe();
        }
        this.fetched = true;
        this.pendingOrders();
        this.draw_turnover();

        // console.log(this.pendings);
      }
    );
  }



  //just check if there are any orders
  pendingOrders() {
    this.all_orders = []; this.all_products = [];

    for (let i = 0; i < this.store.product_class.length; i++) {
      for (let j = 0; j < this.store.product_class[i].orders.length; j++) {
        this.all_orders.push({ order: this.store.product_class[i].orders[j], i: i, j: j });
      }
      this.all_products.push({ pc: this.store.product_class[i], prodName: this.user.username });
    }

    this.all_orders.sort((x, y) =>
      x.order.status - y.order.status
    );
  }


  shprod() {
    this.sh = !this.sh;
  }

  openMyClass(row) {
    this.storeserv.showProductDetails(row);
    this.router.navigateByUrl('product');
  }

  //ACCEPT OR DECLINE
  proccess(ind, i) {
    let ord = this.all_orders[i];
    if (ind == 0) {
      //DECLINE
      this.store.product_class[ord.i].orders.splice(ord.j, 1);
      this.storeserv.updateStore(this.store).subscribe(
        () => {
          this.pendingOrders();  //samo da  bi se ponovo dohvatili podaci
        }
      );
    }
    else {
      //ACCEPT & TRY TO SEND
      if (this.store.available_couriers.valueOf() > 1) {
        this.store.available_couriers = this.store.available_couriers.valueOf() - 1;
        this.store.product_class[ord.i].orders[ord.j].status = ORDER_DELIVERING;
        this.storeserv.updateStore(this.store).subscribe(() =>
          this.storeserv.try_to_deliver(this.store._id, this.store.product_class[ord.i].orders[ord.j]).subscribe()

        );
        this.pendingOrders();
      }
      else {
        this.store.product_class[ord.i].orders[ord.j].status = ORDER_WAITING;
        this.storeserv.updateStore(this.store).subscribe(() => this.pendingOrders());
      }
    }
  }





  draw_turnover() {
    let width = 30;
    let height = 10;
    let data = [];
    let arr = []
    let i = 0;
    this.store.turnover.forEach(el => {
      if (el > height) height = el.valueOf();
      data.push({ day: ++i, sold: el.valueOf() });
    });


    console.log(data);

    var margin = { top: 20, right: 20, bottom: 20, left: 20 };
    //   width = 460 - margin.left - margin.right,
    //  height = 500 - margin.top - margin.bottom;

    // append the svg object to the body of the page
    var svg = d3.select("#my_dataviz")
      .append("svg")
      .attr("width", 700 + margin.left + margin.right)
      .attr("height", 400 + margin.top + margin.bottom)
      .append("g")
      .attr("transform",
        "translate(" + margin.left + "," + margin.top + ")");


    // X axis
    var x = d3.scaleBand()
      .range([0, 700])
      .domain(data.map(function (d) { return d.day }))
      .padding(1);
    svg.append("g")
      .attr("transform", "translate(0, "+height +")")
      .call(d3.axisTop(x))
      .selectAll("text")
      .attr("transform", "translate(+10,-10)rotate(-45)")
      .style("text-anchor", "end");

    // Add Y axis
    var y = d3.scaleLinear()
      .domain([-0.3, height])
      .range([0, 400]);
    svg.append("g")
      .call(d3.axisLeft(y));

    // Lines
    svg.selectAll("myline")
      .data(data)
      .enter()
      .append("line")
      .attr("x1", function (d) { return x(d.day); })
      .attr("x2", function (d) { return x(d.day); })
      .attr("y1", function (d) { return y(d.sold); })
      .attr("y2", y(0))
      .attr("stroke", "black")

    //Horizontale lines

    svg.selectAll("mylinehor")
      .data(data)
      .enter()
      .append("line")
      .attr("x1", function (d) { return 0; })
      .attr("x2", function (d) { return 700; })
      .attr("y1", function (d) { return y(d.sold); })
      .attr("y2", function (d) { return y(d.sold); })
      .attr("stroke", "white")


    // Circles
    svg.selectAll("mycircle")
      .data(data)
      .enter()
      .append("circle")
      .attr("cx", function (d) { return x(d.day); })
      .attr("cy", function (d) { return y(d.sold); })
      .attr("r", "4")
      .style("fill", "#006600")
      .attr("stroke", "black")
  
  
    }


}
