import { Component, OnInit } from '@angular/core';
import { User, AGRICULTURIST, ADMIN, COMPANY } from 'src/app/models/user';
import { UserService, TokenPayload, RegisterResponse } from 'src/app/services/user.service';
import { StoresService } from 'src/app/services/stores.service';


@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {


  credentials: TokenPayload = {
    _id: '',
    username: '',
    password: '',
    email: '',
    date: null,
    place: '',
    person_info: {
      firstName: '',
      lastName: '',
      phone: ''
    },
    company_info: {
      name: ''
    },
    user_type: -1,
    pending: true,
    oldPasswords: []
  }



  fetched: boolean;
  pendings: User[];
  pendings_agri: User[];
  pendings_comp: User[];
  found: boolean;
  mess: string;
  option: number;
  username: string;

  constructor(private auth: UserService, private stores: StoresService) { }

  ngOnInit(): void {
    this.found = false;
    this.option = 0;
    this.pendings = [];
    this.fetched = false;
    this.pendings_agri = [];
    this.pendings_comp = [];


    this.auth.GetPendings().subscribe(
      (pend: User[]) => {
        this.pendings = pend;
        this.pendings.forEach(p => {
          if (p.user_type == AGRICULTURIST) this.pendings_agri.push(p);
          else this.pendings_comp.push(p);
        });
        this.fetched = true;
      }
    );
  }

  clear() {
    this.mess = '';
    this.credentials = {
      _id: '',
      username: '',
      password: '',
      email: '',
      date: null,
      place: '',
      person_info: {
        firstName: '',
        lastName: '',
        phone: ''
      },
      company_info: {
        name: ''
      },
      user_type: -1,
      pending: false,
      oldPasswords: []
    }
  }

  accept(uname, index, type) {
    this.auth.acceptRequest(uname).subscribe(
      (data) => {

        if (type == AGRICULTURIST) {
          this.pendings_agri.splice(index, 1);
        }
        else {
          this.pendings_comp.splice(index, 1);
          }
        });
  }

  decline(uname, index, type) {
    this.auth.deleteUser(uname).subscribe(
      (data) => {
        if (data.deletedCount > 0)
          if (type == AGRICULTURIST) {
            this.pendings_agri.splice(index, 1);
          }
          else {
            this.pendings_comp.splice(index, 1);
          }
      }
    );
  }



  setOption(opt) {
    this.clear();
    this.found = false;
    if (this.option == opt) this.option = 0;
    else this.option = opt;
  }


  empties(): boolean {
    if (this.credentials.username == null || this.credentials.username == ""
      || this.credentials.password == null || this.credentials.password == ""
      || this.credentials.date == null
      || this.credentials.place == null || this.credentials.place == ""
      || this.credentials.email == null || this.credentials.email == ""
    ) {
      return true;
    }

    if (this.credentials.user_type == AGRICULTURIST || this.credentials.user_type == ADMIN) {
      if (this.credentials.person_info.firstName == null || this.credentials.person_info.firstName == ""
        || this.credentials.person_info.lastName == null || this.credentials.person_info.lastName == ""
        || this.credentials.person_info.phone == null || this.credentials.person_info.phone == "") {
        return true;
      }
    }
    else
      if (this.credentials.company_info.name == null || this.credentials.company_info.name == "") {
        return true;
      }

    return false;
  }

//dodavanje korisnika
  submit() {
    //  console.log(this.credentials.company_info.name);
    this.mess = "";
    if (this.empties()) {
      this.mess = "Sva polja moraju biti popunjena!"
    }
    else {
      if (!this.auth.checkEmail(this.credentials.email)){
        this.mess = "Morate uneti pravu email adresu!";
      }
      else {
        if (!this.auth.pass_check(this.credentials.password)) {
          this.mess = "Lozinka nije odgovarajućeg formata! Lozinka ne može biti kraća od 7 znakova, mora početi slovom i sadržati barem po jedno veliko slovo, specijalni karakter i cifru.";
        }
        else {
          this.credentials.pending = false;
          this.auth.add(this.credentials).subscribe(
            (data: RegisterResponse) => {
              if (data.error) {
                this.mess = this.auth.getError();
              }
              else
                 this.mess = "Korisnik uspešno dodat!"
            },
            err => {
              console.error(err)
            });
        }
      }
    }
  }

  find() {
    this.mess = null;
    this.found = false;
    this.auth.findUser(this.credentials.username).subscribe(
      (data: TokenPayload) => {
        if (data != null) {
          this.credentials = data;
          this.username = this.credentials.username;
          this.found = true
        }
        else {
          this.mess = "Nema korisnika sa unetim korisničkim imenom!";
        }
      }
    );

  }

  again() {
    this.found = false;
    this.clear();
  }


  update() {
    this.mess = null;
    this.found = false;

    if (this.empties()) {
      this.mess = "Sva polja moraju biti popunjena!"
    }
    else {


      this.mess = null;
      this.found = false;

      if (this.credentials.user_type == COMPANY) this.credentials.person_info = { firstName: '', lastName: '', phone: '' };
      else this.credentials.company_info = { name: '' };

      this.auth.updateUser(this.credentials, this.username).subscribe(
        (data) => {
          if (data.result) {
            this.mess = "Podaci o korisniku su uspešno ažurirani!";
          }
          else if (data.error) {
            this.mess = "Došlo je do greške, podaci nisu ažurirani!";
          }
        }
      );
    }

  }

  delete() {
    this.mess = null;
    this.found = false;

    if (this.credentials.user_type == COMPANY) this.credentials.person_info = { firstName: '', lastName: '', phone: '' };
    else this.credentials.company_info = { name: '' };

    this.auth.deleteUser(this.username).subscribe(
      (data) => {
        if (data.result) {
          this.mess = `Uspešno ste obrisali korisnika ${this.username}!`;
        }
        else {
          console.log(data.error);
          this.mess = "Došlo je do greške, korisnik nije obrisan!"
        }
      }
    )
  }
}