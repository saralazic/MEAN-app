import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
import { User, AGRICULTURIST, COMPANY } from 'src/app/models/user';
import { Router } from '@angular/router';


@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  details: User;
  logged: boolean;
  message: string;

  constructor(private auth: UserService, private router: Router) { }

  ngOnInit(): void {
    if (this.auth.isLoggedIn()) {
      this.logged = true;
      localStorage.removeItem('reg');

      this.auth.profile().subscribe(
        user => {
          this.details = user;
          if (user.pending == true) {
            this.router.navigate(['pending']);
          }
          else {
            if (user.user_type == AGRICULTURIST) this.router.navigate(['agri']);
            else if (user.user_type == COMPANY) this.router.navigate(['company']);
            else this.router.navigate(['admin']);
          }
        },
        err => {
          console.log(err);
        })
    }
    else {
      if (localStorage.getItem('reg')) {
        localStorage.removeItem('reg');
        this.router.navigateByUrl('register');
      } else {
        this.router.navigateByUrl('login');
      }
    }

  }

}
