import { Component, OnInit } from '@angular/core';
import { NurseryService } from 'src/app/services/nursery.service';
import { User } from 'src/app/models/user';
import { UserService } from 'src/app/services/user.service';
import { Nursery } from 'src/app/models/nursery';

@Component({
  selector: 'app-agriculturist',
  templateUrl: './agriculturist.component.html',
  styleUrls: ['./agriculturist.component.css']
})
export class AgriculturistComponent implements OnInit {
  
//agriculturists personal information
  user: User;

//all nursery gardens from this owner
  nurseries: Nursery[];
  
//flag show, for new garden input form  
  sh: boolean;

//parameters for new nursery garden
  len: number;
  wid: number;
  place: string;
  name: string;

//message shown when you try to add new garden
  mess: string;

//message for maintanence
  maintenance: string; 

  displayedColumns: string[] = ['name', 'place', 'scion_number', 'free_space', 'water', 'temperature'];

  constructor(private nursery: NurseryService, private userserv: UserService) { }

  ngOnInit(): void {
    this.sh = false;
    this.maintenance = "";
    this.mess = null;
    if (localStorage.getItem('userToken')) {
      this.user = this.userserv.getUserDetails();
      //console.log(this.user);
      this.nursery.getOwnersNurseries(this.user._id).subscribe(
          (data) => {
            this.nurseries = data;
            this.nurseries.forEach(element => {
            //  console.log(element);
              if(element.temperature<12 || element.water<75){
                //  console.log(element);
                this.maintenance += `Rasadnik "${element.name}" zahteva održavanje!\n`; 
              }
            });
         //   console.log(this.maintenance);
          }
      );
    }
  }

  show(){
    this.sh = true;
  }

  openMyGarden(row){
    //console.log(row);
    this.nursery.showNGarden(row);
  }
  
  empty(){
    if (this.name == "" || this.name==null || this.place == "" || this.place==null || this.len ==null || this.wid==null)
      return true;
    else return false;
  }

  add(){
    this.mess = null;
    if(this.empty()) { this.mess = "Morate uneti sva polja"; return;}
    if(this.len<=0 || this.wid<=0) { this.mess= "Nekorektan unos"; return; }
    else{ 
      this.nursery.addNewGarden({name: this.name, place: this.place, size: {length: this.len, width: this.wid}, owner: this.user._id, email: this.user.email }).subscribe(
        data => {
          if (data.error) this.mess = "Došlo je do greške, rasadnik nije dodat! Molimo pokušajte ponovo"
          else {
            this.nursery.getOwnersNurseries(this.user._id).subscribe(
              (data2) => { 
                  this.nurseries = data2; 
                  this.maintenance = "";
                  this.nurseries.forEach(element => {
                    //  console.log(element);
                      if(element.temperature<12 || element.water<75){
                        //  console.log(element);
                        this.maintenance += `Rasadnik "${element.name}" zahteva održavanje!\n`; 
                      }
                  });
                  this.mess = "Uspeh";}
            );}
         }
      )
    }
  }

}
