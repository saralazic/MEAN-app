import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pending',
  templateUrl: './pending.component.html',
  styleUrls: ['./pending.component.css']
})
export class PendingComponent implements OnInit {

  message: string;

  constructor() { }

  ngOnInit(): void {
    this.message = "Naši administratori će uskoro odobriti Vaš nalog i moći ćete da koristite sve pogodnosti aplikacije. Hvala na poverenju!"
  }

}
