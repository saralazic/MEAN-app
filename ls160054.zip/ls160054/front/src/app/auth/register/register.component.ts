import { Component, OnInit } from '@angular/core';
import { User, AGRICULTURIST, COMPANY } from 'src/app/models/user';
import { UserService, TokenPayload, RegisterResponse } from 'src/app/services/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  credentials: TokenPayload = {
    _id: '',
    username: '',
    password: '',
    email: '',
    date: null,
    place: '',
    person_info: {
      firstName: '',
      lastName: '',
      phone: ''
    },
    company_info: {
      name: ''
    },
    user_type: -1,
    pending: true,
    oldPasswords: []
  }

  pass1: string;
  mess: string;
  pass_mess: string;
  type: boolean;

  captcha: boolean;

  constructor(private userserv: UserService, private router: Router) { }

  ngOnInit(): void {
    this.captcha = false;
    this.type = true;
    this.mess = null;
    this.pass_mess = null;
    this.clear();
  }


  agri() {
    if (!this.type) this.clear();
    this.type = true;
  }

  comp() {
    if (this.type) this.clear();
    this.type = false;
  }


  clear() {
    this.captcha = false;
    this.credentials = {
      _id: '',
      username: '',
      password: '',
      email: '',
      date: null,
      place: '',
      person_info: {
        firstName: '',
        lastName: '',
        phone: ''
      },
      company_info: {
        name: ''
      },
      user_type: -1,
      pending: true,
      oldPasswords: []
    }
    this.pass_mess = '';
    this.mess = '';
    this.pass1 = '';
  }

  //checkig if any field of submited form is empty
  empties(): boolean {
    if (this.credentials.username == null || this.credentials.username == ""
      || this.credentials.password == null || this.credentials.password == ""
      || this.pass1 == null || this.pass1 == ""
      || this.credentials.date == null
      || this.credentials.place == null || this.credentials.place == ""
      || this.credentials.email == null || this.credentials.email == ""
    ) {
      return true;
    }

    if (this.type) {
      if (this.credentials.person_info.firstName == null || this.credentials.person_info.firstName == ""
        || this.credentials.person_info.lastName == null || this.credentials.person_info.lastName == ""
        || this.credentials.person_info.phone == null || this.credentials.person_info.phone == "") {
        return true;
      }
    }
    else
      if (this.credentials.company_info.name == null || this.credentials.company_info.name == "") {
        return true;
      }

    return false;
  }

  /*
    submitUserForm() {
      var response = grecaptcha.getResponse();
      if (response.length == 0) {
        document.getElementById('g-recaptcha-error').innerHTML = '<span style="color:red;">Ovo polje je obavezno!</span>';
        return false;
      }
      return true;
    }
  
    verifyCaptcha() {
      document.getElementById('g-recaptcha-error').innerHTML = '';
    }
  */


  resolved(captchaResponse: string) {
    this.captcha = false;
    console.log(`Resolved captcha with response: ${captchaResponse}`);
  }

  submit() {
    this.mess = "";
    if (this.captcha == false) {
      this.mess = "Morate potvrditi da niste robot i sva polja moraju biti popunjena!"
    }
    if (this.empties()) {
      this.mess = "Sva polja moraju biti popunjena!"
    }
    else {
      if (!this.userserv.checkEmail(this.credentials.email)) {
        this.mess = "Morate uneti pravu email adresu!"
      }
      if (this.type && !this.userserv.checkPhone(this.credentials.person_info.phone)) {
        this.mess = "Morate uneti validan broj telefona"
      }
      else {
        if (!this.userserv.pass_check(this.credentials.password)) {
          this.mess = "Vaša lozinka nije odgovarajućeg formata! Lozinka ne može biti kraća od 7 znakova, mora početi slovom i sadržati barem po jedno veliko slovo, specijalni karakter i cifru.";
        }
        else {
          if (this.credentials.password != this.pass1) {
            this.pass_mess = "Lozinke se ne poklapaju!";
          }
          else {
            this.credentials.user_type = this.type ? AGRICULTURIST : COMPANY;
            this.credentials.pending = true;
            this.userserv.register(this.credentials).subscribe(
              (data: RegisterResponse) => {
                if (data.error) {
                  this.mess = this.userserv.getError();
                }
              },
              err => {
                console.error(err)
              }
            )
          }
        }
      }
    }
  }
}
