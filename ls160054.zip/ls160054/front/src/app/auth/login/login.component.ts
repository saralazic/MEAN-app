import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';
import { TokenPayload, UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {


  message: string;

  credentials: TokenPayload = {
    _id: '',
    username: '',
    password: '',
    email: '',
    date: null,
    place: '',
    person_info: {
      firstName: '',
      lastName: '',
      phone: ''
    },
    company_info: {
      name: ''
    },
    user_type: -1,
    pending: true,
    oldPasswords: []
  }


  constructor(private userserv: UserService, private router: Router) { }

  ngOnInit(): void {
    this.message = this.userserv.getError();
  }



  empties() {
//    console.log('call' + this.credentials.username + this.credentials.password);
    if (this.credentials.username == '' || this.credentials.username == null
      || this.credentials.password == '' || this.credentials.password == null) {
      this.message = "Sva polja moraju biti popunjena"
      return false;
    }
    else return true;
  }

  login() {
    this.message = null;
    if (this.empties())
      this.userserv.login(this.credentials).subscribe(
        (data) => {
        //  console.log(data);
          this.router.navigateByUrl('/profile');
        }, 
        err => {
          console.log(err);
        }
      )
  }


}


