import { Component, OnInit } from '@angular/core';
import { UserService, TokenPayload, PassResponse } from 'src/app/services/user.service';
import { User } from 'src/app/models/user';

@Component({
  selector: 'app-changepass',
  templateUrl: './changepass.component.html',
  styleUrls: ['./changepass.component.css']
})
export class ChangepassComponent implements OnInit {

  oldPass: string;
  newPass1: string;
  newPass2: string;
  mess: string;
  user: User;
  show: boolean;

  constructor(private userserv: UserService) { }

  ngOnInit(): void {
    this.show = false;
  }

  empties() {
    if (this.oldPass == null || this.oldPass == '') {
      this.mess = "Morate uneti staru lozinku da biste mogli da postavite novu!";
      return true;
    }
    else {
      if (this.newPass1 == null || this.newPass1 == '') {
        console.log("newPass: "+this.newPass1);
        return true;
      }
      else {
        if (this.newPass2 == null || this.newPass2 == '') {
          this.mess = "Morate potvrditi novu lozinku!";
          return true;
        }
        else {
          return false;
        }
      }
    }
  }

  chg(){
    this.show = !this.show;
  }

  change() {
    this.mess = null;
    if (!this.empties()) {
      if (this.newPass1 != this.newPass2) {
        this.mess = "Nova i potvrđena lozinka se ne poklapaju!";
      }
      else if (this.oldPass == this.newPass1) {
        this.mess = "Trenutna i nova lozinka su iste";
      }
      else {
        if (!this.userserv.pass_check(this.newPass1)) {
          this.mess = "Nova lozinka nije odgovarajućeg formata, mora imati bar 7 karaktera, veliko slovo, cifru i specijalni karakter!";
        }
        else {
          if (localStorage.getItem('userToken')) {
            console.log("test");
            this.user=this.userserv.getUserDetails();
                
                this.userserv.checkPass(this.user.username, this.oldPass, this.newPass1).subscribe(
                  (response: PassResponse) => {
                    console.log(response);
                    if (response.error) {
                      this.mess = response.error;
                    }
                    else {
                      if (response.result == false) {
                        this.mess = "Ne može se postaviti stara lozinka. Molimo probajte sa lozinkom koju ranije niste koristili."
                      }
                      else {
                        this.userserv.setPass(this.user.username, this.oldPass, this.newPass1, response.old).subscribe(
                          (data) => {
                            console.log(data);
                            if (!data.error) {
                              this.userserv.logout();
                            }
                          }
                        );
                      }
                    }

                  });              
          }
        }
      }
    }
  }
}

