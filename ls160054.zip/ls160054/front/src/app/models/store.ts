import { ProductClass } from '../services/stores.service';

export class Store{
    _id: String;
    company: String;
    product_class: ProductClass[];
    available_couriers: Number;
    turnover: Number[];
}