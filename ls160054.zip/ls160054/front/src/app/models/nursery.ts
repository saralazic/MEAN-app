import { Product } from './product';

export class Nursery {
    _id: string;
    owner: string;//owner_id
    email: string;
    name: string;
    place: string;
    size: {
        width: number;
        length: number;
    };
    scion_number: number;
    free_space: number;
    temperature: number;
    water: number;
    display: Product[][];
    storage: Product[];

    constructor() {
        this.display = new Array<Array<Product>>();
        for (let i = 0; i < this.size.width; i++) {
            let row: Product[] = new Array<Product>();
            for (let j = 0; j < this.size.length; j++) {
                row.push();
            }
            this.display.push(row);
        }
    }
}