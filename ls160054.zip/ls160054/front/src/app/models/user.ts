export class User{
    _id: String;
    username: String;
    password: String;
    email: String;
    date: Date;
    place: String;
    person_info: {
        firstName: String;
        lastName: String;
        phone: String;
    };
    company_info: {
        name: String;
    };
    user_type: Number;
    pending: Boolean;
    oldPassword: String[];
};

export const AGRICULTURIST = 0;
export const COMPANY = 1;
export const ADMIN= 2;