export class Product{
//    _id: String; 

    name: String;
    type: Number; //0=scion
    //status: Number;
    producer: String;
    progress: Number;
    num_of_days: Number;
};  

export const SCION = 1;
export const PROD = 2;
