import { Component, OnInit } from '@angular/core';
import { ProductClass, StoresService } from 'src/app/services/stores.service';
import { Router } from '@angular/router';
import { User, AGRICULTURIST } from 'src/app/models/user';
import { UserService } from 'src/app/services/user.service';
import { Nursery } from 'src/app/models/nursery';
import { NurseryService } from 'src/app/services/nursery.service';
import { Store } from 'src/app/models/store';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  
  details: ProductClass;
  producer: String;
  user: User;
  nurseries: Nursery[]; //if logged user is agriculturist

  deliver_to: String; //garden_id
  quant: number;
  mess: String;
  can_comment: boolean;
  wantsCom: boolean;

  comment: string;
  grade: number;

  constructor(private nserv: NurseryService, private sserv: StoresService, private router: Router, private userv: UserService) { }

  ngOnInit(): void {
    this.wantsCom = false;
    this.can_comment = false;
    this.mess = null;
    let det = this.sserv.getProductInfo();
    this.details = det.pc;
    this.producer = det.prodName;
    this.user = this.userv.getUserDetails();
    if (this.user.user_type == AGRICULTURIST) {
      this.nserv.getOwnersNurseries(this.user._id).subscribe(
        (data) => this.nurseries = data
      )
    } else this.nurseries = null;
    if (this.user.user_type==AGRICULTURIST) {
      this.details.buyers.forEach(el => {
        if (el == this.user._id) {
          let cannot = false;
          this.details.rating.forEach(r => 
            {
              if (r.user._id == this.user._id){
                cannot = true;
              }
            }
          );
          if (cannot==false) this.can_comment = true;
        };
      });
    }
  }


  openMyClass(row) {
    this.sserv.showProductDetails(row);
    this.router.navigateByUrl('product');
  }

  order() {
    console.log("order");
    this.mess = null;
    console.log(this.deliver_to);
    this.nserv.getGardenById(this.deliver_to).subscribe(
      (data) => {
        if (data.result){
          if(this.details.onStock >= this.quant){
             this.sserv.newOrder(this.details.producer, this.details.name, this.user, this.quant, data.result);
             this.mess = `Naručili ste ${this.quant} komada ovog proizvoda`;
            }
            else {
              this.mess = `Nema dovoljno proizvoda na stanju!`;

            }
      }}
    );
  }


  putComment(){
    this.details.rating.push({
      user: this.user,
      comment: this.comment,
      grade: this.grade
    });

    let avg=0;
    this.details.rating.forEach(
      el => {
        avg=avg + el.grade.valueOf();
      }
    );

    avg = avg/this.details.rating.length;
    this.details.average = avg;
    
    console.log(avg);


    this.can_comment = false;
    this.sserv.getStore(this.details.producer).subscribe(
      (store: Store) => {
          for(let i=0; i<store.product_class.length; i++){
            if(store.product_class[i].name==this.details.name){
              store.product_class[i]=this.details;
              break;
            }
          };
          this.sserv.updateStore(store).subscribe(()=> {
           // let d = { pc: this.details, prodName: this.producer };
            this.sserv.showProductDetails(this.details);
          });
      }
    );
  }


  shCom(){
    this.wantsCom = !this.wantsCom;    
  }

  
}

