import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { User } from 'src/app/models/user';
import { NurseryService } from 'src/app/services/nursery.service';
import { StoresService } from 'src/app/services/stores.service';
import { UserService } from 'src/app/services/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-steper',
  templateUrl: './steper.component.html',
  styleUrls: ['./steper.component.css']
})
export class SteperComponent implements OnInit {

  isLinear = true;
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  thirdFormGroup: FormGroup;
  fourthFormGroup: FormGroup;
  fifthFormGroup: FormGroup;
  mess: string;
  user: User;
  tip: number;

  constructor(private _formBuilder: FormBuilder, private userv: UserService, private sserv: StoresService, private router: Router) { }

  ngOnInit() {
    this.user = this.userv.getUserDetails();
    this.mess = null;
    this.firstFormGroup = this._formBuilder.group({
      firstCtrl: ['', Validators.required]
    });
    this.secondFormGroup = this._formBuilder.group({
      secondCtrl: ['', Validators.required]
    });
    this.thirdFormGroup = this._formBuilder.group({
      thirdCtrl: ['', Validators.required]
    });
    this.fourthFormGroup = this._formBuilder.group({
      fourthCtrl: ['', Validators.required]
    });
    this.fifthFormGroup = this._formBuilder.group({
      fifthCtrl: ['', Validators.required]
    });
  }

  submit() {
    /* 
        console.log(this.firstFormGroup.value.firstCtrl);
        console.log(this.secondFormGroup.value.secondCtrl);
        console.log(this.thirdFormGroup.value.thirdCtrl);
        console.log(this.fourthFormGroup.value.fourthCtrl);
     */

    if (this.thirdFormGroup.value.thirdCtrl <= 0 ||
      this.fourthFormGroup.value.fourthCtrl <= 0 ||
      this.fifthFormGroup.value.fifthCtrl <= 0) {
      this.mess = "Nekorektan unos!"
    }
    else {
      let data = {
        producer: this.user._id,
        name: this.firstFormGroup.value.firstCtrl,
        type: this.secondFormGroup.value.secondCtrl,
        num_of_days: this.thirdFormGroup.value.thirdCtrl,
        price: this.fourthFormGroup.value.fourthCtrl,
        num: this.fifthFormGroup.value.fifthCtrl
      };

      this.sserv.addNewProductClass(data);
      this.router.navigate(['company']);
    }
  }

}
