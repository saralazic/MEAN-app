import { Component, OnInit } from '@angular/core';
import { Store } from '../../models/store'
import { Router } from '@angular/router';
import { ProductClass, StoresService, Order, ORDER_PENDING, ORDER_WAITING } from '../../services/stores.service';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-store',
  templateUrl: './store.component.html',
  styleUrls: ['./store.component.css']
})
export class StoreComponent implements OnInit {

  stores: Store[];
  products: {pc: ProductClass, prodName: String}[];
  fetched: boolean;

  my_orders: {ord: number, pc: number, store: Store, order: Order}[];

  displayedColumns: string[] = ['name', 'type', 'producer', 'onstock', 'grade'];

  constructor(private sserv: StoresService, private userv: UserService, private router: Router) { }

  ngOnInit(): void {
    this.getData();
  }

  getData(){
    
    this.fetched = false;
    this.products = [];
    this.my_orders = [];

    this.sserv.getAllStores().subscribe(
      (data) => {
        this.stores = data;
        let i=0;
        this.stores.forEach(element => {
          element.product_class.forEach(
            prod => {
              let p = prod;
              this.userv.findUserById(prod.producer).subscribe(
                (user) => {
                  this.products.push({pc: p, prodName: user.username});
                });

              let j=0;
              p.orders.forEach(ord=> {
                if ((ord.status == ORDER_PENDING  || ord.status == ORDER_WAITING) &&  ord.buyer._id == this.userv.getUserDetails()._id){
                  this.my_orders.push({ord: j, pc: i, store: element, order: ord});
                }
                j++;
              });
            }
          );
          i++;
        });
        this.fetched = true;
      }
    );
  }

  openMyClass(row){
 //   console.log(this.products);
    this.sserv.showProductDetails(row);
    this.router.navigateByUrl('product');
  }


  
  cancel_order(row: {ord: number, pc: number, store: Store, order: Order}, index: number){
      row.store.product_class[row.pc].orders.splice(row.ord, 1);
      this.my_orders.splice(index, 1);
      this.sserv.updateStore(row.store).subscribe(
        () => this.getData()
      );
  }


}
