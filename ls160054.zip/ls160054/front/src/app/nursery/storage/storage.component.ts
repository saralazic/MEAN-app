import { Component, OnInit } from '@angular/core';
import { Product, SCION } from 'src/app/models/product';
import { NurseryService } from 'src/app/services/nursery.service';
import { UserService } from 'src/app/services/user.service';
import { PlantingInfo, StoresService } from 'src/app/services/stores.service';
import { Router } from '@angular/router';
import { element } from 'protractor';

export const ADD_SCION = 0;
export const ADD_PROD = 1;
export const BOTH = 2;

@Component({
  selector: 'app-storage',
  templateUrl: './storage.component.html',
  styleUrls: ['./storage.component.css']
})
export class StorageComponent implements OnInit {

  products: { product: Product, producer: String} []; //preparati
  scions: { product: Product, producer: String} [];
  action: number;


  constructor(private nserv: NurseryService, private userv: UserService, private sserv: StoresService, private router: Router) {}

  ngOnInit(): void {
    this.action = this.nserv.getGardenAction();
    this.scions = [];
    this.products = [];
    let p: Product[];
    p = this.nserv.showStorage();
    p.forEach(element => {
      this.userv.findUserById(element.producer).subscribe(
      (prod) =>{
        if(element.type == SCION){
          this.scions.push({product: element, producer:prod.username});
      }
      else this.products.push({product: element, producer:prod.username});
    });
  });
  console.log(this.products);
  console.log(this.scions);
  }



  //PLANTING 
  plant(s: { product: Product, prodcer: String}, i: number){
    let pinf: PlantingInfo;
    pinf = this.sserv.getCoord();

    //add to garden
    pinf.garden.display[pinf.x][pinf.y] = s.product;
    
    //delete from list on the page
    this.scions.splice(i, 1);

    let index;
    //delete from storage
    for(let j=0; j<pinf.garden.storage.length; j++){
      if (pinf.garden.storage[j]==s.product) 
          index = j;
    }
    pinf.garden.storage.splice(index, 1);
   
    //change info about scion number and free places 
    pinf.garden.scion_number++;
    pinf.garden.free_space--;

    //set info for showing
    this.nserv.setStorage(pinf.garden.storage);

    //update a garden in database
    this.nserv.updateGarden(pinf.garden).subscribe(() => { 
      this.nserv.setGarden(pinf.garden);  
      this.router.navigate(['garden'])
    });   
  }


  //ADD PRODUCT
  add_product(s: { product: Product, prodcer: String}, i: number){
    let pinf: PlantingInfo;
    pinf = this.sserv.getCoord();
    

    //delete from list on the page
    this.products.splice(i, 1);

    let index;
    //delete from storage
    for(let j=0; j<pinf.garden.storage.length; j++){
      if (pinf.garden.storage[j]==s.product) 
          index = j;
    }
    pinf.garden.storage.splice(index, 1);

    //progress update
    let progress = pinf.garden.display[pinf.x][pinf.y].progress.valueOf();
    //console.log(progress);

    let sum = pinf.garden.display[pinf.x][pinf.y].num_of_days.valueOf();
    //console.log(sum);

    let days = progress/100.0;
    days = days * sum; 
    //console.log(days);
    //console.log(s.product.num_of_days.valueOf());


    
    progress = days + parseInt(s.product.num_of_days.valueOf().toString());

    //console.log(progress);

    progress = 100 * progress / sum;

    //console.log(progress);

    if  (progress>100) progress = 100;

    pinf.garden.display[pinf.x][pinf.y].progress = progress;

    
   //set info for showing
    this.nserv.setStorage(pinf.garden.storage);

    //update a garden in database
    this.nserv.updateGarden(pinf.garden).subscribe(() => { 
    this.nserv.setGarden(pinf.garden);  
    this.router.navigate(['garden'])
  });       
    
  }
}


