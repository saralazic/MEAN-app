import { Component, OnInit } from '@angular/core';
import { Nursery } from 'src/app/models/nursery';
import { NurseryService } from 'src/app/services/nursery.service';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  garden: Nursery;

  constructor(private ng: NurseryService) { }

  ngOnInit(): void {
    this.garden = this.ng.getGarden();
  }

  incdec(type, param){
    if (type ==0){ //temperature
    if (param == 0){
      this.garden.temperature--;
    }
    else this.garden.temperature++;
   }
   else { //water
    if (param == 0){
      this.garden.water--;
    }
    else this.garden.water++;
   }

   this.ng.updateGarden(this.garden).subscribe(
     (data) => {
       if (data.result) {
         if (data.result.nModified > 0) {
            this.ng.setGarden(this.garden);
             }
         }
  });
}
}
