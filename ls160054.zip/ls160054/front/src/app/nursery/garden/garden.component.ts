import { Component, OnInit } from '@angular/core';
import { NurseryService } from 'src/app/services/nursery.service';

import { Nursery } from 'src/app/models/nursery';
import { Router } from '@angular/router';
import { ADD_SCION, ADD_PROD } from '../storage/storage.component';
import { StoresService } from 'src/app/services/stores.service';




@Component({
  selector: 'app-garden',
  templateUrl: './garden.component.html',
  styleUrls: ['./garden.component.css']
})
export class GardenComponent implements OnInit {

 
  ngrd: Nursery;

  constructor(private ngservice: NurseryService, private router: Router, private sstorage: StoresService) {
   }

  ngOnInit(): void {
    this.ngrd = this.ngservice.getGarden();
  }

  dig_out(i, j){
    this.ngrd.display[i][j].num_of_days = 0;
    this.ngservice.updateGarden(this.ngrd).subscribe();
  }

  addProduct(i, j){
    this.ngservice.setStorage(this.ngrd.storage);
    this.ngservice.setGardenAction(ADD_PROD);
    this.sstorage.saveCoord({garden: this.ngrd, x: i, y: j});
    this.router.navigate(['/storage']);
  }

  addScion(i, j){
      this.ngservice.setStorage(this.ngrd.storage);
      this.ngservice.setGardenAction(ADD_SCION);
      this.sstorage.saveCoord({garden: this.ngrd, x: i, y: j});
      this.router.navigate(['/storage']);
  }



}
