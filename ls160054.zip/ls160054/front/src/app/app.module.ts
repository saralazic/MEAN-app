import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RecaptchaModule } from 'ng-recaptcha';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import { MatStepperModule, MatStepperIntl } from '@angular/material/stepper';
import { MatInputModule } from '@angular/material/input';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './auth/login/login.component';
import { LogoutComponent } from './auth/logout/logout.component';
import { RegisterComponent } from './auth/register/register.component';
import { HeaderComponent } from './marginals/header/header.component';
import { FooterComponent } from './marginals/footer/footer.component';
import { AdminComponent } from './users/admin/admin.component';
import { CompanyComponent } from './users/company/company.component';
import { AgriculturistComponent } from './users/agriculturist/agriculturist.component';
import { HttpClientModule } from '@angular/common/http';
import { PendingComponent } from './users/pending/pending.component';
import { ProfileComponent } from './users/profile/profile.component';
import { ChangepassComponent } from './auth/changepass/changepass.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { GardenComponent } from './nursery/garden/garden.component';
import { DashboardComponent } from './nursery/dashboard/dashboard.component';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { StoreComponent } from './store/store/store.component';
import { SteperComponent } from './store/steper/steper.component';
import { CommonModule } from '@angular/common';
import { STEPPER_GLOBAL_OPTIONS } from '@angular/cdk/stepper';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatLabel, MatFormField, MatFormFieldModule } from '@angular/material/form-field';
import { ProductComponent } from './store/product/product.component';

import { AgmCoreModule } from '@agm/core';
import { StorageComponent } from './nursery/storage/storage.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    LogoutComponent,
    RegisterComponent,
    HeaderComponent,
    FooterComponent,
    AdminComponent,
    CompanyComponent,
    AgriculturistComponent,
    PendingComponent,
    ProfileComponent,
    ChangepassComponent,
    GardenComponent,
    DashboardComponent,
    StoreComponent,
    SteperComponent,
    ProductComponent,
    StorageComponent
  ],
  imports: [
    BrowserModule,
    RecaptchaModule,
    CommonModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    MatTableModule,
    MatProgressBarModule,
    BrowserAnimationsModule,
    MatStepperModule, 
    MatIconModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyCe313V2KwtWyiihHF8ZyqiQj5UVXoIRtg'
    })
  ],
  exports: [
    BrowserModule,
    CommonModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    MatTableModule,
    MatProgressBarModule,
    BrowserAnimationsModule,
    MatStepperModule, 
    MatIconModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule
  ],
  providers: [
    {
      provide: STEPPER_GLOBAL_OPTIONS,
      useValue: { displayDefaultIndicatorType: false }
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
