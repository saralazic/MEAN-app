import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { User } from '../models/user';
import { Store } from '../models/store';
import { Router } from '@angular/router';
import { UserService } from './user.service';
import { MapsAPILoader } from '@agm/core';
import { Nursery } from '../models/nursery';
import { Time } from '@angular/common';


export interface Order {
  quantity: number,
  deliver_to: Nursery,
  distance: number,
  buyer: User,
  status: number,
  stamp: any;
}

export interface ProductClass {
  name: String;
  type: Number;
  producer: String;
  price: number;
  onStock: number;
  num_of_days: number;
  orders: Order[]; //we have to save User, not just his id, because we need place to ship the order
  buyers: String[]; ///ids
  rating: {
    comment: String;
    user: User; //id 
    grade: Number;
  }[],
  average: Number;
}

export interface PlantingInfo{
  garden: Nursery; 
  x:number;
  y: number;
} 


export const ORDER_PENDING = 1;
export const ORDER_WAITING = 0;
export const ORDER_DELIVERING = 2;
export const ORDER_DELIVERED = 3;


@Injectable({
  providedIn: 'root'
})
export class StoresService {

  constructor(private http: HttpClient, private router: Router, private userserv: UserService, private _mapsAPILoader: MapsAPILoader) { }


  saveCoord(data: PlantingInfo){
    localStorage.setItem('garden-job', JSON.stringify(data));
  }

  getCoord(): PlantingInfo {
    return JSON.parse(localStorage.getItem('garden-job'));
  }

  newStore(comp_id): Observable<any> {
    return this.http.post('store/add', { company: comp_id });
  }

  //get store by company id
  getStore(comp_id): Observable<any> {
    return this.http.get(`store/get-one/${comp_id}`);
  }

  //get all stores
  getAllStores(): Observable<any> {
    return this.http.get('store/all');
  }

  updateStore(body: Store): Observable<any> {
    return this.http.put(`store/update/${body._id}`, body);
  }

  addNewProductClass(data) {
    this.getStore(data.producer).subscribe(
      (s) => {
        let store = s;
        let newProd = {
          name: data.name,
          type: data.type,
          producer: data.producer,
          price: data.price,
          onStock: data.num,
          num_of_days: data.num_of_days,
          orders: [],
          buyers: [],
          rating: [],
          average: 0
        };

        store.product_class.push(newProd);
        this.updateStore(store).subscribe(() => console.log(store));
      });
  }

  showProductDetails(data) {
    localStorage.setItem('product', JSON.stringify(data));
  }

  getProductInfo(){
    return JSON.parse(localStorage.getItem('product'));
  }


  //Do I need to add it on stock
  /*
    addNewProductOnStock(prod: Product) {
      this.getStore(prod.producer).subscribe(
        s => {
            let store = s;
            store.product_class.forEach(element => {
              if (element.name == prod.name) {
                element.onStock++;
              }
            });
            this.updateStore(store).subscribe();
          }
      );
    }
  */

  try_to_deliver(store: String, order: Order): Observable<any> {
    return this.http.put(`store/deliver`, {
      order: order,
      store_id:  store
    });
  };

  newOrder(producer: String, name: String, buyer: User, num: Number, deliver_to: Nursery){
    let mess: String;
    let date = new Date();
    this.getStore(producer).subscribe(
      s => {
        let store = s;
        this.userserv.findUserById(producer).subscribe(
          (prod) => {
            this._mapsAPILoader.load().then(() => {
              new google.maps.DistanceMatrixService().getDistanceMatrix({ 'origins': [prod.place], 'destinations': [deliver_to.place], travelMode: google.maps.TravelMode.DRIVING }, (results: any) => {
                let time = results.rows[0].elements[0].duration.value; //time in seconds
                /*
                let h = Math.floor(time / 3600);
                let min = Math.floor((time-h*3600)/60);
                */
               // console.log(time);
                store.product_class.forEach(element => {
                  if (element.name == name) {
                    if (element.onStock > num) {
                      element.orders.push({
                        quantity: num,
                        deliver_to: deliver_to,
                        distance: 7*1000, //time in miliseconds
                        buyer: buyer,
                        status: ORDER_PENDING,
                        stamp: date.getTime()
                      });
                      this.updateStore(store).subscribe();
                    }
                   
                  }
                });
                return mess;
              });
            });
          });
      });
  }

}
