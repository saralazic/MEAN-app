import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { User, AGRICULTURIST, COMPANY, ADMIN } from '../models/user';
import { Observable, of } from 'rxjs';
import { map } from 'rxjs/operators';


interface TokenResponse {
  token: string;
  error: string;
}

export interface RegisterResponse {
  status: string;
  error: string;
}

export interface PassResponse{
  result: boolean;
  error: string;
  old: string[];
}

export interface TokenPayload {
  _id: string;
  username: string;
  password: string;
  email: string;
  date: Date;
  place: string;
  person_info: {
    firstName: string;
    lastName: string;
    phone: string;
  };
  company_info: {
    name: string;
  };
  user_type: number;
  pending: boolean;
  oldPasswords: string[];
}

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private token: string;

  constructor(private http: HttpClient, private router: Router) { }

  private setError(err: string) {
    localStorage.setItem('error', err);

  }

  public getError(): string {
    let error = localStorage.getItem('error');
    localStorage.removeItem('error');
    return error;

  }

  private saveToken(token: string): void {
    localStorage.setItem('userToken', token);
    this.token = token;
  }

  private getToken(): string {
    if (!this.token) {
      this.token = localStorage.getItem('userToken');
    }
    return this.token;
  }

  public getUserDetails(): User {
    const token = this.getToken();
    let payload;
    if (token) {
      payload = token.split('.')[1];
      payload = window.atob(payload);
      return JSON.parse(payload)
    } else {
      return null;
    }
  }

  public isLoggedIn(): boolean {
    const user = this.getUserDetails();
    if (user) {
      return true
    } else {
      return false
    }
  }


//Check if passwords format is correct
  public pass_check(pass: string): boolean {
    return (/^(?=.{8,}$)(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*\W).*$/.test(pass) && /^[a-zA-Z]/.test(pass));
  }

  public checkEmail(email: string): boolean{
    return (/(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\])/.test(email));
  }


  public checkPhone(phone: string): boolean{
    return (/^(060|061|062|063|006)\d{7}$/).test(phone) || (/^(0)\d{8}$/).test(phone);
  }


  public add(user: TokenPayload): Observable<any> {
    localStorage.removeItem('error');
    console.log(user.company_info.name);
    const base = this.http.post('/users/register', user);
    const request = base.pipe(
      map((data: RegisterResponse) => {
        if (!data.status)
          this.setError(data.error);
        return data;
      })
    )
    return request;
  }



  public register(user: TokenPayload): Observable<any> {
    localStorage.removeItem('error');
    const base = this.http.post('/users/register', user);
    const request = base.pipe(
      map((data: RegisterResponse) => {
        if (data.status) {
          if(user.user_type == COMPANY) {
          }
          this.router.navigate(['pending']);
        }
        else this.setError(data.error)
        return data;
      })
    )
    return request;
  }

  public login(user: TokenPayload): Observable<any> {
    localStorage.removeItem('error');
    const base = this.http.post('/users/login', user);

    const request = base.pipe(
      map((data: TokenResponse) => {
        if (data.token) {
          this.saveToken(data.token);
        }
        else this.setError(data.error);
        return data
      })
    )
    return request;
  }

  public profile(): Observable<any> {
    return this.http.get('users/profile', {
      headers: { Authorization: `${this.getToken()}` }
    })
  }

  public findUser(uname): Observable<any> {
    return this.http.get(`users/user/${uname}`);
  }

  public findUserById(id): Observable<any>{
    return this.http.get(`users/get-user/${id}`);
  }

  public deleteUser(username): Observable<any> {
    return this.http.delete(`users/user/${username}`);
  }

  public acceptRequest(username): Observable<any> {
    return this.http.put(`users/accept/${username}`, {});
  }

  public GetPendings(): Observable<any> {
    return this.http.get('users/pendings')
  }

  public updateUser(user: TokenPayload, username: string): Observable<any> {

    return this.http.put(`users/update/${username}`,
      {
        username: user.username,
        password: user.password,
        email: user.email,
        date: user.date,
        place: user.place,
        person_info: {
          firstName: user.person_info.firstName,
          lastName: user.person_info.lastName,
          phone: user.person_info.phone
        },
        company_info: {
          name: user.company_info.name
        },
        user_type: user.user_type,
        pending: user.pending
      });

  }


//checking if new password is equal to some of users previous passwords
  checkPass(uname, oldpass, newpass): Observable<any>{
    return this.http.post(`users/check-pass`, {username: uname, oldPassword: oldpass, newPassword: newpass});
  }

  setPass(uname, oldpass, newpass, old): Observable<any>{
    return this.http.put(`users/set-pass`, { username: uname, password: oldpass, newPassword: newpass, oldPasswords: old })
  }

  public logout(): void {
    this.token = '';
    localStorage.removeItem('userToken')
    this.router.navigateByUrl('/')
  }



}


