import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Nursery } from '../models/nursery';
import { Router } from '@angular/router';
import { Product } from '../models/product';

@Injectable({
  providedIn: 'root'
})
export class NurseryService {

  constructor(private http: HttpClient, private router: Router) { }

  public getOwnersNurseries(_id): Observable<any> {
    return this.http.get(`nursery/own/${_id}`);
  }


  public addNewGarden(body): Observable<any>{
    return this.http.post(`nursery/add`, body);
  }


  public setGarden(g: Nursery) {
    localStorage.setItem('NurseryGarden-to-show', JSON.stringify(g));
  }

  public showNGarden(g: Nursery) {
    localStorage.setItem('NurseryGarden-to-show', JSON.stringify(g));
    this.router.navigate(['garden']);
  }

  public setGardenAction(s: number){
    localStorage.setItem('GardenAction', JSON.stringify(s));
  }

  public getGardenAction(): number{
    return JSON.parse(localStorage.getItem('GardenAction'));
  }

  public setStorage(s: Product[]){
    localStorage.setItem('Storage-to-show', JSON.stringify(s));
  }

  public showStorage(){
    return JSON.parse(localStorage.getItem('Storage-to-show'));
  }



  public getGardenByName(g):  Observable<any>{
    return this.http.get(`nursery/find-by-name/${g}`);
  }


  public getGardenById(id): Observable<any>{
    return this.http.get(`nursery/get-one/${id}`);
  }

  /*
  public getProduct(id: string): Observable<any> {
    return this.http.get(`/product/get-one/${id}`);
  }
  */

  public getGarden(): Nursery {
    return JSON.parse(localStorage.getItem('NurseryGarden-to-show'));
  }


  getProducerInfo(id): Observable<any> {
    return this.http.get(`users/get-user/${id}`);
  }

  public updateGarden(garden: Nursery): Observable<any> {
    return this.http.put(`nursery/update/${garden._id}`,
      {
        owner: garden.owner,
        email: garden.email,
        name: garden.name,
        place: garden.place,
        size: {
          width: garden.size.width,
          length: garden.size.length
        },
        scion_number: garden.scion_number,
        free_space: garden.free_space,
        temperature: garden.temperature,
        water: garden.water,
        display: garden.display,
        storage: garden.storage
      });
  }

  

}
