import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './auth/login/login.component';
import { RegisterComponent } from './auth/register/register.component';
import { AgriculturistComponent } from './users/agriculturist/agriculturist.component';
import { AdminComponent } from './users/admin/admin.component';
import { CompanyComponent } from './users/company/company.component';
import { PendingComponent } from './users/pending/pending.component';
import { ProfileComponent } from './users/profile/profile.component';
import { ChangepassComponent } from './auth/changepass/changepass.component';
import { GardenComponent } from './nursery/garden/garden.component';
import { SteperComponent } from './store/steper/steper.component';
import { ProductComponent } from './store/product/product.component';
import { StoreComponent } from './store/store/store.component';
import { StorageComponent } from './nursery/storage/storage.component';



const routes: Routes = [
  {path: '', component: LoginComponent},
  {path: 'login', component: LoginComponent}, 
  {path: 'register', component: RegisterComponent},
  {path: 'agri', component: AgriculturistComponent},
  {path: 'admin', component: AdminComponent},
  {path: 'company', component: CompanyComponent},
  {path: 'pending', component: PendingComponent},
  {path: 'profile', component: ProfileComponent},
  {path: 'changepass', component:ChangepassComponent},
  {path: 'garden', component: GardenComponent},
  {path: 'steper', component: SteperComponent},
  {path: 'product', component: ProductComponent},
  {path: 'onlinestore', component: StoreComponent},
  {path: 'storage', component: StorageComponent}
];

RouterModule.forRoot(routes, { useHash: true });


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
