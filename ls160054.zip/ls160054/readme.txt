baza: 
u konzoli promeniti path tako da je ...\MongoDB\...\bin
kopirati na C disk mydb folder
-komanda:
mongorestore -d rasadnik C:\mydb\mydb
