const mongoose = require('mongoose');

const UserSchema = mongoose.Schema(
    {
        username: {
            type: String,
            require: true,
            unique: true
        },
        password: {
            type: String,
            require: true
        },
        email: {
            type: String,
            require: true
        },
        date: {
            //datum rodjenja za korisnika, odnosno datum osnivanja za firmu
            type: Date,
            require: true
        },
        place: {
            //mesto rodjenja za korisnika, odnosno mesto osnivanja za firmu
            type: String,
            require: true
        },
        person_info: {
            firstName: { type: String },
            lastName: { type: String },
            phone: { type: String }
        },
        company_info: {
            name: { type: String }
        },
        user_type: {
            type: Number,   
            require: true
        },
        pending: {
            type: Boolean,
            require: true
        },
        oldPasswords: {
            type: [String]
        }

    });

const User = module.exports = mongoose.model('User', UserSchema);


