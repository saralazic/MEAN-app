const mongoose3 = require('mongoose');

const StoreSchema = mongoose3.Schema(
    {
        company: {  //id of a company
            type: String,
            require: true
        },
        product_class: {
            type: [Object]  //here goes array of informations about products 
        },
        available_couriers: {
            type: Number
        },
        turnover: {
            type: [Number]
        }
    });

const Store = module.exports = mongoose3.model('Store', StoreSchema);






