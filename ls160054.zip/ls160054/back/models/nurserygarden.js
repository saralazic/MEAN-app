const mongoose1 = require('mongoose');

const NurserySchema = mongoose1.Schema(
    {
        owner: {
            type: String,
            require: true
        },
        email: {
            type: String,
            require: true
        },
        name: {
            type: String,
            require: true
        },
        place: {
            type: String,
            require: true
        },
        size:{
        width: {
            type: Number,
            require: true
        },
        length: {
            type: Number,
            require: true
        }},
        scion_number:{
            type: Number,
            require: true
        },
        free_space: {
            type: Number,
            require: true
        },
        temperature: {
            type: Number,
            require: true
        },
        water: {
            type: Number,
            require: true
        },
        display: {
            type: [[ Object ]],
            require: true
        },
        storage: {
            type: [Object],
            require: true
        }
    });

const NurseryGarden = module.exports = mongoose1.model('NurseryGarden', NurserySchema);






