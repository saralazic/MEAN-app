var bodyParser = require('body-parser');
var express = require('express');
var cors = require('cors');

var app = express();
app.use(bodyParser.urlencoded({ extended: false }));

var mongoose = require('mongoose');
var port = process.env.port || 3000;

app.use(bodyParser.json());
app.use(cors());

const mongoURI = 'mongodb://localhost:27017/rasadnik';

mongoose.connect(mongoURI, { useNewUrlParser: true }).then(() => console.log('MongoDB Connected')).catch(err => console.log(err));

var Users = require('./routes/Users');
var NurseryGardens = require('./routes/Nursery');
var Store = require('./routes/Store')

app.use('/users', Users);
app.use('/nursery', NurseryGardens);
app.use('/store', Store);

app.listen(port, function(){
    console.log('Server is running on port '+ port);
})
