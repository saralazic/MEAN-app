const express = require('express');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');

const users = express.Router();

const User = require("../models/user");
users.use(cors());

process.env.SECRET_KEY = 'secret';


//Register user
users.post('/register', (req, res) => {
    let userData={
        username: req.body.username,
        password: req.body.password,
        email: req.body.email,
        date: req.body.date,
        place: req.body.place,
        person_info: {
            firstName: req.body.person_info.firstName,
            lastName: req.body.person_info.lastName,
            phone: req.body.person_info.phone
        },
        company_info: {
            name: req.body.company_info.name
        },
        user_type: req.body.user_type,
        pending: req.body.pending,
        oldPasswords: req.body.oldPasswords
    };

    User.findOne({
        username: req.body.username
    }).then(user => {
        if (!user) {
            bcrypt.hash(req.body.password, 10, (err, hash) => {
                userData.password = hash
                User.create(userData).then(user => {
                    res.json({ status: userData.username + ", uspesna registracija" })
                }).catch(err => {
                    res.send('error: ' + err);
                })
            });
        }
        else {
            res.json({ error: 'Korisnik sa tim korisničkim imenom već postoji. Molimo pokušajte drugo!' })
        }
    }).catch(err => {
        res.send('error: ' + err);
    })
});



//Login
users.post('/login', (req, res) => {
    User.findOne({
        username: req.body.username
    }).then(user => {
        if (user) {
            if (bcrypt.compareSync(req.body.password, user.password)) {
                const payload = {
                    _id: user._id,
                    username: user.username,
                    person_info: user.person_info,
                    company_info: user.company_info,
                    user_type: user.user_type,
                    place: user.place,
                    date: user.date,
                    email: user.email,
                    pending: user.pending,
                    oldPasswords: user.oldPasswords
                }
                let token = jwt.sign(payload, process.env.SECRET_KEY);
                res.json({ token: token, error: null })
            } else {
                res.json({ token: null, error: "Pogrešna lozinka!" });
            }
        } else {
            res.json({ token: null, error: "Nepostojeće korisničko ime" })
        }
    }).catch(err => {
        res.send('error: ' + err);
    })
})



//Get user data 
users.get('/profile', (req, res) => {
    var decoded = jwt.verify(req.headers['authorization'], process.env.SECRET_KEY);

    User.findOne({
        _id: decoded._id
    }).then(user => {
        if (user) {
            res.json(user)
        } else {
            res.send("Korisnik ne postoji");
        }
    }).catch(err => res.send('error: ' + err));
});

//Check if current password is ok and new password is different from all old passwords
users.post('/check-pass', (req, res) => {
    User.findOne({
        username: req.body.username
    }).then(user => {
        if (user) {
            if (bcrypt.compareSync(req.body.oldPassword, user.password)) {
                //good current password, check new password
                let status = true;
                for (let i = 0; i < user.oldPasswords.length; i++) {
                    if (bcrypt.compareSync(req.body.newPassword, user.oldPasswords[i])) {
                        status = false;
                    }
                }
                res.json({ result: status, old: user.oldPasswords, error: null });
            } else {
                res.json({ result: false, error: "Pogrešna lozinka!" });
            }
        } else {
            res.json({ result: false, error: "Nepostojeće korisničko ime" })
        }
    }).catch(err => {
        res.send('error: ' + err);
    })
});


//Set new password
users.put('/set-pass', (req, res) => {
    let pass;
    let old = req.body.oldPasswords;
    bcrypt.hash(req.body.newPassword, 10, (err, hash) => {
        pass = hash;
        bcrypt.hash(req.body.password, 10, (err, hash2) => {
            old[old.length] = hash2;
            User.updateOne({ username: req.body.username }, {
                password: pass,
                oldPasswords: old
            }, function (err, result) {
                if (err) {
                    res.json({ error: err, result: null });
                }
                else res.json({ error: null, result: result });
            });
        });
    });
});

//Get user data 
users.get('/profile', (req, res) => {
    var decoded = jwt.verify(req.headers['authorization'], process.env.SECRET_KEY);

    User.findOne({
        _id: decoded._id
    }).then(user => {
        if (user) {
            res.json(user)
        } else {
            res.send("Korisnik ne postoji");
        }
    }).catch(err => res.send('error: ' + err));
});


//Get user by username
users.get('/user/:username', (req, res, next) => {
    //    console.log(req.params.username);
    User.findOne({ username: req.params.username }, function (err, result) {
        if (err) {
            res.json(err);
        }
        else {
            res.json(result);
        }
    });
});

users.get('/get-user/:id', (req, res, next) => {
    //    console.log(req.params.username);
    User.findOne({ _id: req.params.id }, function (err, result) {
        if (err) {
            res.json(err);
        }
        else {
            res.json(result);
        }
    });
});

//Get all users (including pendings)
users.get('/all', (req, res) => {
    User.find().then(users => {
        if (users) res.json(users);
        else res.send("Prazna baza!");
    }).catch(err => res.send('error: ' + err));
});

//Get all pending requests
users.get('/pendings', (req, res) => {
    User.find({ pending: true }).then(
        pendings => res.json(pendings)
    ).catch(err => res.send('error: ' + err));
})


//Delete user (find by username)
//(Decline registration request)
users.delete('/user/:username', (req, res, next) => {
    //    console.log(req.params.username);
    User.deleteOne({ username: req.params.username }, function (err, result) {
        if (err) {
            res.json({ error: err, result: null });
        }
        else {
            res.json({ error: null, result: result });
        }
    });
});

//Delete user (find by id)
users.delete('/userDelId/:id', (req, res, next) => {
    //    console.log(req.params.username);
    User.deleteOne({ _id: req.params.id }, function (err, result) {
        if (err) {
            res.json({ error: err, result: null });
        }
        else {
            res.json({ error: null, result: result });
        }
    });
});

//Accept registration request(change pending status)
users.put('/accept/:username', (req, res, next) => {
    User.updateOne({ username: req.params.username }, { pending: false }, function (err, result) {
        if (err) {
            res.json(err)
        }
        else res.json(result)
    });
});

//Update user
users.put('/update/:username', (req, res, next) => {
    User.updateOne({ username: req.params.username }, {
        username: req.body.username,
        password: req.body.password,
        email: req.body.email,
        date: req.body.date,
        place: req.body.place,
        person_info: {
            firstName: req.body.person_info.firstName,
            lastName: req.body.person_info.lastName,
            phone: req.body.person_info.phone
        },
        company_info: {
            name: req.body.company_info.name
        },
        user_type: req.body.user_type,
        pending: req.body.pending
    }, function (err, result) {
        if (err) {
            res.json({ error: err, result: null });
        }
        else res.json({ error: null, result: result });
    });
});



module.exports = users;