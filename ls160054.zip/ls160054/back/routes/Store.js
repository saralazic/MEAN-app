const express = require('express');
const stores = express.Router();
var schedule_store = require('node-schedule');
const Store = require('../models/store');

const Nursery = require('../models/nurserygarden');
const store = require('../models/store');


var l = schedule_store.scheduleJob('35 23 * * *', function () {
    // console.log("scheduled");
    Store.find().then(
        (stores) => {
            stores.forEach(element => {
                if (element.turnover.length < 30) {
                    while (element.turnover.length < 30) {
                        element.turnover.push(0);
                    }
                };
                element.turnover.splice(0, 1);
                element.turnover.push(0);

                Store.updateOne({ _id: element._id }, {
                    turnover: element.turnover
                }).then();
            });
        });
});



//add new store
stores.post('/add', (req, res) => {
    let arr = [];
    for (let i = 0; i < 30; i++) arr.push(0);

    let data = {
        company: req.body.company,
        product_class: [],
        available_couriers: 6,
        turnover: arr
    };

    Store.create(data).then(
        res.json("Uspešno dodata prodavnica " + data.company)
    ).catch(err => {
        res.send('error: ' + err);
    })
});


//get all stores
stores.get('/all', (req, res) => {
    Store.find().then(p => {
        if (p) res.json(p);
        else res.send("Prazna baza!");
    }).catch(err => res.send('error: ' + err));
});


//get store by company id (has to be id because username can be changed)
stores.get('/get-one/:id', (req, res) => {
    Store.findOne({ company: req.params.id }).then(
        store => {
            res.json(store);
        }
    ).catch(err => {
        res.send('error: ' + err);
    })
});


//update a store
stores.put('/update/:_id', (req, res, next) => {
    Store.updateOne({ _id: req.params._id }, {
        company: req.body.company,
        product_class: req.body.product_class,
        available_couriers: req.body.available_couriers,
        turnover: req.body.turnover
    }, function (err, result) {
        if (err) {
            res.json({ error: err, result: null });
        }
        else {
            // console.log(result);
            res.json({ error: null, result: result });
        }
    });
});





//try to deliver(
stores.put('/deliver', (req, res, next) => {
    //console.log("zove funkciju" + req.body.store.available_couriers);
    setTimeout(finish_delivery, req.body.order.distance, req.body.store_id, req.body.order);

});



function finish_delivery(store_id, order) {
    //   console.log(store.available_couriers);
    let pc;

    //make one courier available
    Store.findOne({ _id: store_id }).then(
        (store) => {
            store.available_couriers = store.available_couriers + 1;

            Nursery.findOne({ _id: order.deliver_to._id }).then(
                (nurs) => {
                    store.product_class.forEach(element => {
                        element.orders.forEach(
                            o => {
                                if (o.stamp == order.stamp) {
                                    o.status = 3; //DELIVERED
                                    element.onStock = element.onStock - order.quantity;
                                    store.turnover[29] = store.turnover[29] + order.quantity;
                                    pc = element;

                                    let ind = false;
                                    element.buyers.forEach(el => {
                                        if (el == nurs.owner) ind = true;
                                    }
                                    );

                                    if (ind == false) element.buyers.push(nurs.owner); //save buyer


                                    Store.updateOne({ _id: store._id }, {
                                        company: store.company,
                                        product_class: store.product_class,
                                        available_couriers: store.available_couriers,
                                        turnover: store.turnover
                                    }, function (err, result) {
                                        if (err) {
                                            console.log(err);
                                        }
                                        else {
                                            // console.log(result);
                                            for (let i = 0; i < order.quantity; i++)
                                                order.deliver_to.storage.push({
                                                    name: pc.name,
                                                    type: pc.type,
                                                    producer: pc.producer,
                                                    progress: 0,
                                                    num_of_days: pc.num_of_days
                                                });//new products added into storage                   

                                            //update nursery
                                            Nursery.updateOne({ _id: order.deliver_to._id }, {
                                                storage: order.deliver_to.storage
                                            }).then(() => { console.log("gotovo") });
                                        }
                                    });
                                }
                            })
                    })
                })
        })
}

module.exports = stores;