const express = require('express');
const cors = require('cors');
var schedule = require('node-schedule');
var nodemailer = require('nodemailer');

const ng = express.Router(); //nursery garden

const Nursery = require("../models/nurserygarden");
ng.use(cors());



var transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'mojrasadnik10@gmail.com',
        pass: 'rasadnikmoj10*'
    },
    tls: {
        rejectUnauthorized: false
    }
});

var s = schedule.scheduleJob('07 21 * * *', function () {
    // console.log("zakazivanje radi");
    Nursery.find().then(
        (gardens) => {

            gardens.forEach(element => {
                for(let i=0; i<element.size.width; i++){
                    for(let j=0; j<element.size.length; j++){
                        if (element.display[i][j]!=null){
                            if (element.display[i][j].progress == 100 && element.display[i][j].num_of_days==0){
                                element.display[i][j]=null;
                                element.free_space = element.free_space + 1;
                                element.scion_number = element.scion_number - 1;
                            }
                        }
                    }
                }
                Nursery.updateOne({ _id: element._id },
                    {
                        scion_number: element.scion_number,
                        free_space: element.free_space,
                        display: element.display
                    }).then();
            });
            ;
        }
    );
}
);

var j = schedule.scheduleJob('16 * * * *', function () {
    // console.log("zakazivanje radi");
    Nursery.find().then(
        (gardens) => {

            gardens.forEach(element => {
                Nursery.updateOne({ _id: element._id },
                    {
                        temperature: element.temperature - 0.5,
                        water: element.water - 1
                    }).then();
            });
            ;
        }
    );
}
);

var k = schedule.scheduleJob('02 * * * *', function () {
    Nursery.find().then(
        (gardens) => {
            gardens.forEach(element => {
                if (element.temperature < 12 || element.water < 75) {
                    var mailOptions = {
                        from: 'mojrasadnik10@gmail.com',
                        to: element.email,
                        subject: 'Hitna poruka',
                        text: `Vašem rasadniku <i>${element.name}</i> je neophodno održavanje`
                    };

                    transporter.sendMail(mailOptions, function (error, info) {
                        if (error) console.log(error)
                        else console.log('Email sent ' + info.response);
                    })
                }
            });
        });
}
);

var l = schedule.scheduleJob('02 20 * * *', function () {
   // console.log("scheduled");
    Nursery.find().then(
        (gardens) => {
            gardens.forEach(element => {
                for (let i = 0; i < element.size.width; i++) {
                    for (let j = 0; j < element.size.length; j++) {
                        if (element.display[i][j] != null) {
                            if (element.display[i][j].progress < 100) {
                                let days = (element.display[i][j].progress * element.display[i][j].num_of_days / 100) + 1;
                                element.display[i][j].progress = days * 100 / element.display[i][j].num_of_days;
                            //    console.log(element.display[i][j].progress);
                            }
                        }
                    }
                }
                Nursery.updateOne({ _id: element._id }, {
                    display: element.display
                }).then();
            });

        });
});

//Add new nursery garden 
ng.post('/add', (req, res) => {
    let l = req.body.size.length;
    let w = req.body.size.width;

    let p = l * w;

    //matrix
    var arr = [];
    var i, j;
    for (i = 0; i < w; i++) {
        arr.push([]);
        arr[i].push(new Array(l));
        for (j = 0; j < l; j++)
            arr[i][j] = null;
    }

    data = {
        owner: req.body.owner,
        email: req.body.email,
        name: req.body.name,
        place: req.body.place,
        size: {
            length: l,
            width: w
        },
        scion_number: 0,
        free_space: p,
        temperature: 18,
        water: 200,
        display: arr,
        storage: []
    };

    Nursery.create(data).then(
        res.json({ res: "Uspešno dodat rasadnik " + data.name, error: null })
    ).catch(err => {
        console.log('error: ' + err);
    })
});



//Get all nursery gardens
ng.get('/all', (req, res) => {
    Nursery.find().then(gardens => {
        if (gardens) res.json(gardens);
        else res.send("Prazna baza!");
    }).catch(err => res.send('error: ' + err));
});



//Get nursery garden by its ID
ng.get('/get-one/:id', (req, res) => {
    Nursery.findOne({ _id: req.params.id }, function (err, result) {
        if (err) {
            res.json({ error: err, result: null });
        }
        else {
            res.json({ error: null, result: result });
        }
    });
});


//Get all gardens from one owner (owners id, NOT USERNAME!!!)
ng.get('/own/:owner', (req, res) => {
    Nursery.find({ owner: req.params.owner }).then(
        (gardens) => {
            if (gardens) res.json(gardens);
            else res.send("Prazna baza!");
        }
    )
});


//Update garden
ng.put('/update/:_id', (req, res, next) => {
    Nursery.updateOne({ _id: req.params._id }, {
        owner: req.body.owner,
        name: req.body.name,
        email: req.body.email,
        place: req.body.place,
        size: {
            length: req.body.size.length,
            width: req.body.size.width
        },
        scion_number: req.body.scion_number,
        free_space: req.body.free_space,
        temperature: req.body.temperature,
        water: req.body.water,
        display: req.body.display,
        storage: req.body.storage
    }, function (err, result) {
        if (err) {
            res.json({ error: err, result: null });
        }
        else {
            // console.log(result);
            res.json({ error: null, result: result });
        }
    });
});

ng.delete('/del/:id', (req, res, next) => {
    Nursery.deleteOne({ _id: req.params.id }, function (err, result) {
        if (err) {
            res.json({ error: err, result: null });
        }
        else {
            res.json({ error: null, result: result });
        }
    });
});


ng.put('/delivered_product/:id', (req, res, next) => {
    Nursery.findOne({ _id: req.params.id },
        function (err, result) {
            if (err) {
                res.json({ error: err, result: null });
            }
            else {
                //  res.json({ error: null, result: result });
            }
        }).then(
            console.log(result)
        );
}
);

module.exports = ng;